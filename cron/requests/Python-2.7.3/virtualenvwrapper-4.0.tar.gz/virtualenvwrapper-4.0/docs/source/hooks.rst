===============================
 Customizing Virtualenvwrapper
===============================

virtualenvwrapper adds several hook points you can use to change your
settings, shell environment, or other configuration values when
creating, deleting, or moving between environments. These hooks are
exposed in two ways:

.. toctree::
   :maxdepth: 1

   scripts
   plugins
